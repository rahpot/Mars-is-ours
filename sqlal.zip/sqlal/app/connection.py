from sqlal.app.data.db_session import global_init, create_session
from sqlal.app.data.users import User

db_name = input()


def connect(db_name):
    global_init(db_name)
    db_sess = create_session()
    db_sess.commit()
    for user in db_sess.query(User).filter(User.address == 'module_1',
                                           User.position.notlike('%engineer%'),
                                           User.speciality.notlike('%engineer%')):
        print(user.id)


connect(db_name)
