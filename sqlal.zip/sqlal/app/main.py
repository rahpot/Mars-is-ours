from flask import Flask
from sqlal.app.data import db_session
from sqlal.app.data.users import User
from sqlal.app.data.jobs import Jobs
from sqlal.app.data.departments import Departments
from flask import render_template
from flask import redirect
from sqlal.app.forms.register import RegisterForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/blogs.db")

    @app.route('/jobs')
    def run_jobs():
        db_sess = db_session.create_session()
        jobs = db_sess.query(Jobs)
        return render_template("jobs.html", jobs=jobs)

    @app.route('/register')
    def register():
        form = RegisterForm()
        if form.validate_on_submit():
            if form.password.data != form.r_password.data:
                return render_template('register.html', title='Регистрация',
                                       form=form, message="Пароли не совпадают")
            db_sess = db_session.create_session()
            if db_sess.query(User).filter(User.email == form.login.data).first():
                return render_template('register.html', title='Регистрация',
                                       form=form, message="Логин занят")
            user = User(
                surname=form.surname.data,
                name=form.name.data,
                age=form.age.data,
                position=form.position.data,
                speciality=form.speciality.data,
                address=form.address.data,
                email=form.login.data,
            )
            user.set_password(form.password.data)
            db_sess.add(user)
            db_sess.commit()
            return redirect('/login')
        return render_template('register.html', title='Регистрация', form=form)

    app.run()


if __name__ == '__main__':
    main()
