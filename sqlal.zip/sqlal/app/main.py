from flask import Flask
from sqlal.app.data import db_session
from sqlal.app.data.users import User
from sqlal.app.data.jobs import Jobs
from flask import render_template
from flask import redirect

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/blogs.db")
    @app.route('/jobs')
    def run_jobs():
        db_sess = db_session.create_session()
        jobs = db_sess.query(Jobs)
        return render_template("jobs.html", jobs=jobs)

    app.run()

if __name__ == '__main__':
    main()
